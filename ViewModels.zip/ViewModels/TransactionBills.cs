﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HousetaxBillingSystem.Models;

namespace HousetaxBillingSystem.ViewModels
{
    public class TransactionBills
    {
        public int BillId { get; set; }
        public int TransactionId { get; set; }
        public int? CustomerId { get; set; }
        public string CustomerName { get; set; }
        public int? BillAmount { get; set; }
        public string Status { get; set; }
    }
}